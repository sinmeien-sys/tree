# CH6 层次树图可视化 / Hierarchical Tree Visualization

基于 **Node.js + D3 v7** 的层次树图可视化作业，一套数据驱动 6 种树图，含装饰花朵与配色版。

## 运行方式

```bash
node server.js
# 浏览器访问 http://localhost:3000/
```

服务器为零依赖的原生 Node.js 静态服务（`server.js`），默认端口 3000（可用环境变量 `PORT` 修改）。

## 目录结构

```
.
├── server.js              # Node.js 静态文件服务器（item 1）
└── public/
    ├── index.html         # 主页面：6 种树图 + 花朵 + 配色 + 标题排版
    ├── d3.v7.min.js        # D3 v7
    ├── theme.json          # 自整理的主题数据：可视化知识体系（item 4）
    ├── d3v3tree.json       # 课程提供数据
    └── flare.json          # 课程提供数据
```

## 作业要点对照

| 要求 | 实现 |
|------|------|
| 1. Node.js 服务器 + d3v3.json | `server.js`；数据下拉可选 `d3v3tree.json` |
| 2. 直角坐标横/纵层次树图，叶节点对齐/层级对齐，1 变 4 | `d3.tree`(层级对齐) / `d3.cluster`(叶节点对齐) × 纵向`linkVertical` / 横向`linkHorizontal` = 4 种 |
| 3. 极坐标树图，叶节点对齐/层级对齐，共 2 | `d3.tree` / `d3.cluster` + `linkRadial` = 2 种 |
| 4. 整理 .json 主题数据并加载 | `theme.json`（数据可视化知识体系），默认加载 |
| 5. 页面 Title+CopyRight，横纵混排 | 顶部章节号纵排 + 标题横排 + 版权纵排，页脚混排 |
| 6. 配色版 / 色彩数组 | `:root` CSS 变量 + JS `PALETTE` 数组，工具栏色卡展示 |
| 7. d3.pie + d3.arc 画 2 朵花 🌺 | `drawFlower()`，标题栏内 2 朵装饰花 |

## 本课小结

- `d3.hierarchy` —— 解析 JSON 数据对象
- `d3.tree` —— 层级对齐（潮汐图），参数决定直角 / 极坐标
- `d3.cluster` —— 叶子节点对齐，参数决定直角 / 极坐标
- `d3.linkHorizontal()` —— 水平贝塞尔曲线
- `d3.linkVertical()` —— 垂直贝塞尔曲线
- `d3.linkRadial()` —— 径向贝塞尔曲线
